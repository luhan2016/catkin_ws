import matplotlib.pyplot as plt
import csv
import sys

sys.path.append('../..')
from utils.Intersection import *

time = []
state = [] #x, y, theta, v
course = []
nmb_state_var = 4
intention = []
#id = -1

with open("../Test_1/1541082879__mn_coordinates.csv") as state_data:
    reader = csv.reader(state_data, delimiter=',')
    #print(next(reader)) #(time, states, (id, turn, Is))
    nmb_vehicles = (len(next(reader))-3)/nmb_state_var
    #print(nmb_vehicles)
    state_data.seek(0)
    for i in range(0,nmb_vehicles):
        state.append([])
    for row in reader:
        time.append(row[0][1:])
        for i in range(0,nmb_vehicles):
            state[i].append([row[nmb_state_var*i+1][3:], row[nmb_state_var*i+2][1:], row[nmb_state_var*i+3][1:], row[nmb_state_var*i+4][1:-2]])
        #id = row[nmb_vehicles*nmb_state_var+1][2:]
        course.append(row[nmb_vehicles*nmb_state_var+2][1:])
        intention.append(row[nmb_vehicles*nmb_state_var+3][1:-2])
#print(state)

#Calculate headway when inferring correctly
#intersection = Intersection()
course_obj = Course("south", course[0])
print(state[0][1])
print(course_obj.getTimeToCrossing(float(state[0][0][0]),float(state[0][0][1]),float(state[0][0][2]),float(state[0][0][3]),"go"))
print(course[0])