#!/usr/bin/env python
#import zmq
import calendar
from datetime import datetime
import time
from threading import Timer
import random
import zookeeper
import socket
import argparse
import rospy
import virtual_blinker.msg as cm
import std_msgs 
import threading
import maneuver_negotiator_config
import os
import sys

sys.path.append("..")
from config import *
RATE = SIM_CONFIG['rate']
SLOWDOWN = SIM_CONFIG['slowdown']


class ManeuverNegotiator:  

  ## DEFINE THE STATES
  NORMAL = 1    # Initial state, no requests sent and no grant given
  GET = 2       # Waiting for replies from agents in the Safety Membership set
  GRANTGET = 3  # Grant given to other agent but this agent also wants to ask for permission to do a maneuvre
  GRANT = 4     # Grant given to other agent and this agent doesn't want to do a maneuvre
  EXECUTE = 5   # All permissions recieved
  TRYGET = 6    # Some agents in the Safety Membership set aren't reachable or have answered DENY to our request

  def __init__(self,sim, agent_id,intersection, communication_details,risk_estimator,initial_direction=None):
    print "maneuver_negotiatir.py in the maneuver negotiator. py init function - - start"
    self.sim = sim
    #Make all the necessary variables global
    #all global variables in romi code is now instance variabes:
    self.status = self.NORMAL
    #self.TMan = 10
    self.T_RETRY = 3
    self.T_GRANT = 10
    self.aID = agent_id
    self.tRetry = []
    self.t_grant = []
    self.handle  =[ ] # Zookeeper handle, init this please
    self.grantID = 0  # Id of agent with active grant (The one the vehicle have given a grant to)
    self.tag = [0,0,"intended_course"]  # Associated with a message, on the form: [timestamp, agent id, turn]
    self.agents_to_ask = [] # Agents in this vehicles Membership Registry
    #these were initialized later in romis code
    #self.T_UPDATE = 5
    self.timeTaken = 0
    #self.time1 = self.clock() # this variable is not used in romi's code
    #self.TM = maneuver_negotiator_config.GENERAL_OPTIONS['TM']   # Period of membership protocol
    self.TMan = maneuver_negotiator_config.GENERAL_OPTIONS['TMan']  # Maneuvre time
    self.TA = maneuver_negotiator_config.GENERAL_OPTIONS['TA']     # Period of agent registry update (how often the agents x, v and a is sampled )
    self.TD = maneuver_negotiator_config.GENERAL_OPTIONS['TD']    # Upper bound on transmission delay
    self.M = set()
    self.D = set()
    self.R = set()
    #self.time_delay = 100
    #intersection at which the cars are setup
    #intersection = None
    #all measurements are updated to this variable
    #at the same frequency as simulation publishes them.
    #everytime romi's code calls clock() position()
    #velocity() acceleration(), measurements are taken from this variable
    #make dummy testMsg
    cs1 = cm.CarState()
    cs1.x = 1
    cs1.y = 1
    cs1.theta = 1
    cs1.speed = 1
    #cs1.acceleration = 1
    cs1.id = 1
    self.ros_measurements = cs1
    print "call clock function"
    self.agent_state = [self.clock(), 1,1,1] #dummy vars for now
    self.agent = [agent_id,self.agent_state]
    self.intersection = intersection
    #self.initialize(zookeeper_ip)
    self.communication_details = communication_details
    #used in no_conflict to check risk
    self.risk_estimator = risk_estimator
    self.maneuver_requested=None #maneuver requested in trymaneuver
    self.my_travelling_direction = initial_direction
    self.watch_sender = False
    self.watch_sender_course = None
    self.watch_sender_Tman_upperbound  = None
    print "maneuver_negotiatir.py call the clock(), give the clock to self.agent_state"
    print "maneuver_negotiatir.py in the maneuver negotiator. py init function finish"

  def clock(self):
    print "self.ros_measurements is None"
    if self.ros_measurements is None:
      print "maneuver_negotiatir.py in the clock function the ros_measurements is empty, so return 1"
      return 1
    else:
      print "self.ros_measurements is not empty"
      print self.ros_measurements
      print "current clock is {}".format(float(self.ros_measurements.t/(RATE*SLOWDOWN)))
      return float(self.ros_measurements.t/(RATE*SLOWDOWN))

  ## Get current position
  def position(self):
    print "maneuver_negotiatir.py this is get posotion function, it's important for me to read other car's location"
    return (float(self.ros_measurements.x), float(self.ros_measurements.y),float(self.ros_measurements.theta))

  ## Get current velocity
  def velocity(self):
    print "maneuver_negotiatir.py get the velocity"
    return int(self.ros_measurements.speed)

  ## Get current acceleration
  def acceleration(self):
    print "maneuver_negotiatir.py get the acceleration"
    return 1

  ## Retry timer expired, tell the other agents to stop their lease of grant to you. Change status to TRYGET since all agents in R can't be reached
  def t_retry(self,intended_course):
    print "maneuver_negotiatir.py in the t_retry function, all agnets in resopnse agnet set can not reached"
    status = self.status
    agents_to_ask = self.agents_to_ask
    print("reached retry trymaneuver")
    if(status == self.GET): # If timer expired for this vehicles current request, ask other agents in D to release their grants
      self.status = self.TRYGET
      print "!!!!!!!!!!change status from get to tryget(tried get, already get), Some agents in the Safety Membership \
            set aren't reachable or have answered DENY to our request"
      message = "RELEASE," + str(self.agent[0]) + "," + str(self.agent[1][0]) + "," + str(self.agent[1][1]) + "," \
              + str(self.agent[1][2]) + "," + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1])
      for agents in self.agents_to_ask:
        print(message)
        self.send_udp_message(message,int(agents))
      print "call tryManeuver from t_retry>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
      self.tRetry = Timer(2*self.TD, self.t_retry, args=(intended_course,))
      self.tRetry.start()
    self.tryManeuver(intended_course)

  def get_MR(self,id1,intended_course):
    print "maneuver_negotiatir.py get membership, in the get_MR function, start"
    #EME: Suggested change (Requires zookeeper to be set up properly)
    (data, stat) = zookeeper.get(self.handle, "/root/mr/" + str(id1)) 
    data = eval(data)
    print "maneuver_negotiatir.py intended_course"
    print intended_course
    membership = data[intended_course]
    print "membership is {}".format(membership)
    mr_separator = ","
    membership[2]  = mr_separator.join(membership[2])
    print membership[0]
    print membership[1]
    print membership[2]
    print "maneuver_negotiatir.py get membership, in the get_MR function, finish"
    return membership
    #Without membership
    #(data, stat) = zookeeper.get(self.handle, "/root/segment/" + str(id1), True)
    #children = zookeeper.get_children(self.handle, "/root/segment", True)
    #ask_these = ""
    #for child in children:
    #  if(child != str(id1)):
    #    ask_these = ask_these + str(child) + ","
    #ask_these = ask_these[0:len(ask_these)-1]
    #print "ask_these = " + str(ask_these)
    #print "ask_these of type" + str(type(ask_these))
    #return [stat["mtime"], 1, str(ask_these)]

  def tryManeuver(self,intended_course=None):

    print "maneuver_negotiatir.py in the trymaneuver function - start$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
    self.maneuver_requested = intended_course

    print "1.self.status is {}".format(self.status)

    if (self.status == self.NORMAL or self.status == self.GRANT):
      self.tag = [self.clock(), self.aID, intended_course]
      print "!!!!after check statue the self.tag is {}".format(self.tag)

    print "2.self.status is {}".format(self.status)

    if (self.status == self.NORMAL or self.status == self.TRYGET):
      self.status = self.TRYGET

      print "change normal to tryget(for the case tryget, it doesn't need to chcnge)"

      self.agent_state = [self.clock(), self.position(), self.velocity(), self.acceleration()]
      self.agent = [self.aID,self.agent_state]


      MR = self.get_MR(self.agent[0],intended_course)

      print "self.agent_state[0] is {}".format(self.agent_state[0])
      print "(RATE*SLOWDOWN) is {}".format((RATE*SLOWDOWN))
      print "MR[0] is {}".format(MR[0])
      print "self.TMan is {}".format(self.TMan)


      if(( self.agent_state[0]/(RATE*SLOWDOWN) < MR[0] + 2*self.TMan) and MR[1] == 1):
        print "( self.agent_state[0]/(RATE*SLOWDOWN) < MR[0] + 2*self.TMan) and MR[1] == 1"
        if(',' in MR[2]):
          self.agents_to_ask = MR[2].split(',')
        elif MR[2] == '':
          self.agents_to_ask = []
          print("Empty")
        else:
          self.agents_to_ask = [MR[2]]

        print "self.agents_to_ask is {}".format(self.agents_to_ask)

        for car in self.agents_to_ask:
          self.D.add(str(car))
          self.R.add(str(car))

        message = "GET," + str(self.agent[0]) + "," + str(self.agent[1][0]) + "," + str(self.agent[1][1]) + "," \
                + str(self.agent[1][2]) + "," + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1])
        if (intended_course is not None): 
          message = "GET," + str(self.agent[0]) + "," + str(self.agent[1][0]) + "," + str(self.agent[1][1]) + "," \
                  + str(self.agent[1][2]) + "," + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1]) + "," + str(intended_course)
        print"message is :{}".format(message)

        self.status = self.GET
        print "!!!!change state to get"
        for agents in self.agents_to_ask:
          print(message)
          self.send_udp_message(message,int(agents))
        self.tRetry = Timer(2*self.TD, self.t_retry, args=(intended_course,))
        self.tRetry.start()
      else:
        print "( self.agent_state[0]/(RATE*SLOWDOWN) < MR[0] + 2*self.TMan) and MR[1] == 1 xxxxxxx"
        self.tRetry = Timer(self.TA, self.t_retry, args=(intended_course,)) # Wait until a fresh membership is available
        self.tRetry.start()
    elif (self.status == self.GRANT):
      self.status = self.GRANTGET
      print "!!!!change state to GRANTGET"
    print "finish try maneuver"

  ## Estimate the expectation of the car with register mAR. No conflict if weighted average over a certain threshold
  def no_conflict(self, mAR, time_tick):
    global RATE
    global SLOWDOWN
    current_time = time_tick/(RATE*SLOWDOWN)
    print("maneuver_negotiatir.py in no conflict funtion , start")
    print "current time is ", time_tick/(RATE*SLOWDOWN)
    #mAR = [m_dict["Sender"], m_dict["Time"], m_dict["Position"], m_dict["Velocity"], m_dict["Acc"]]
    sender = mAR[0]
    sent_time = float(mAR[1])
    sender_pose =map(float,mAR[2])
    sender_speed = float(mAR[3])
    sender_acceleration = float(mAR[4])
    if(len(mAR)>5):
      sender_maneuver = mAR[5]
    """
    No conflict checks time sender enters and leaves intersection overlaps with 
    the recieving vehicle.
    Current scenario is sender is a left turning vehicle, receiver is a straight
    passing vehicle.
    We first estimate earliest and last possible time left turning vehicle can enter 
    the intersection. We estimate the earliest and last possible time left turning
    vehicle can leave. we take earliest enter and last leave duration 
    """
    #calculate earliest possible time sender can enter:
    #this earliest time is when sender receives grant almost immediately , like within 5 ms
    #we project where the car will be after like 5ms using stop profile
    #we then project when the car will arrive at 
    #first, get the course the sender is taking:
    #this can be done from sender_position and sender_course
    my_state = self.position()
    my_speed = self.velocity()
    my_travelling_direction = self.my_travelling_direction
    if (my_travelling_direction is None):
      #this happens while i am at the intersection
      print("maneuver_negotiatir.py my travelling direction is none")
      print "my state is ", my_state
      return False
    my_course = self.intersection.courses[(my_travelling_direction,"straight")]
    my_entering_time = current_time + my_course.getTimeToCrossing(my_state[0],my_state[1],my_state[2],my_speed,"go")
    my_leaving_time = my_entering_time + my_course.getTimeToEndOfCrossing(my_state[0],my_state[1],my_state[2],my_speed)
    stop_interval = 0.005
    if (my_course.hasLeftIntersection(*my_state)):
      return True
    sender_travelling_direction = self.intersection.getTravellingDirection(*sender_pose)
    if (sender_travelling_direction is None):
      print("maneuver_negotiatir.py sender travel direction is none")
      #print "sender state is ", sender_pose
      return False
    else:
      print "sender travel direction is: ", sender_travelling_direction
    sender_course = self.intersection.courses[(sender_travelling_direction,sender_maneuver)]
    stop_pose_state = sender_course.predictNextState_old(sender_pose[0],sender_pose[1],sender_pose[2],sender_speed,stop_interval,"stop")
    #fromthen onwards it will take profile of go:
    sender_earliest_entering_time = current_time + stop_interval + \
                                    sender_course.getTimeToCrossing(stop_pose_state[0],stop_pose_state[1],stop_pose_state[2],stop_pose_state[3],"go")
    stop_pose_state = sender_course.predictNextState_old(sender_pose[0],sender_pose[1],sender_pose[2],sender_speed,2*self.TD,"stop")
    #last_entering_time = current_time + (2*self.TD) + sender_course.getTimeToCrossing(*stop_pose_state,"go")
    sender_last_entering_time = current_time + (2*self.TD) + \
                                    sender_course.getTimeToCrossing(stop_pose_state[0],stop_pose_state[1],stop_pose_state[2],stop_pose_state[3],"go")
    sender_last_leaving_time = sender_last_entering_time + sender_course.getTimeToEndOfCrossing(*stop_pose_state)
    print "sender earliest entering time is: ", sender_earliest_entering_time
    print "sender last entering time is: ", sender_last_entering_time
    print "sender last leaving time is: ", sender_last_leaving_time
    print "my entering time is: ", my_entering_time
    print "my leaving time is: ", my_leaving_time
    not_conflicted = False
    #not conflicted because either party has left the intersection
    print "i have left the intersection: ", my_course.hasLeftIntersection(*my_state)
    if (sender_course.hasLeftIntersection(*sender_pose)):
      return True
    safe_gap = my_entering_time - sender_last_leaving_time
    if (safe_gap > 0): #means if I enter intersection later than sender leaves, safe.
      print("not conflicted because I enter after sender leaves")
      #in this case, our estimation says the sender leaves before i enter, but
      #due to unforseen circumstances, sender may slowdown and stop inside
      #the intersection, in this case we have to detect if the vehicle requested is able to finish
      #maneuver in time. if we detect ahead of time that the vehicle will not be able to finish the 
      #maneuver in time, we have to slow our car down,
      #this detection needs to be done only when granting.
      #there can be instances where there are no conflicts and still cannot grant because
      #this vehicle is not in NORMAL state or some other cases. So, 
      #in here we flag ourself to look for the other vehicle once we are sure we are granting
      #the vehicle permission, that happens after no_conflict call and when we want to grant.
      # we check the following flags and signal the simulator loop to watch for the other vehicle.
      #watch the requester and detect if the vehicle will leave the intersection in time.
      #start a separate thread on it:
      #def watch_maneuver_requester(self,requester_id,requester_course,requester_maneuver):
      #self.watch_request_thread = threading.Thread(target=self.watch_maneuver_requester,args=(sender,sender_course,sender_maneuver,sender_last_leaving_time))
      #self.watch_request_thread.start()
      self.watch_sender_course = sender_course
      self.watch_sender = True
      self.watch_sender_Tman_upperbound = sender_last_entering_time + self.TMan
      not_conflicted = True
    else: 
      #then we have to compare my leaving time vs his entering time:
      if sender_earliest_entering_time > my_leaving_time: # if sender enters intersection later than I leaves
        print("not conflicted because sender enters after i leave")
        not_conflicted = True
    #things could be optimized here by checking if sender enters intersection 
    #while this vehicle is about to leave. 
    #in this if condition, it checks this just about to leave is like within one second. 
    #which may be save
    if ( (my_leaving_time - sender_earliest_entering_time  <= 0.2) and (my_leaving_time - sender_earliest_entering_time) >=0):
      print("sender enters just im about to leave")
      print "time is " ,(sender_earliest_entering_time - my_leaving_time)
      not_conflicted = True
    print "finish not_conflicted"
    return not_conflicted

    #calculate least    possible time sender can enter:
    #offset these two by TMan to get earliest and last possible exit times. 
    #take the last possible time 
    #return self.risk_estimator.isManeuverOk(int(sender),sender_course)

  ## Dummy function, the agent got permissions from everyone in the SM and executes the manoeuvre in t time units
  def doManeuver(self,t):
    print "maneuver_negotiatir.py in the domaneuver function - start"

    self.risk_estimator.add_car_to_grantlist(self.aID,self.TMan,self.maneuver_requested)

    print("Doing maneuver")

    self.sim.granted = True
    time.sleep(t)
    self.sim.granted = False
    print "maneuver_negotiatir.py finish the do maneuver function"

  ## Returns true when GRANT/DENY received from the last agent
  ## in agents_to_ask, that is agents in the SM
  def last(self):
    print "maneuver_negotiatir.py in the lat function"
    print(len(self.R))
    if(len(self.R) == 0):
      print "maneuver_negotiatir.py the R response set is empty, so return 1, why 1. what 1 means, is that car 1"
      return 1
    print "maneuver_negotiatir.py the R response set is not empty, so return 0, why 0, is that car 0"
    return 0

  ## Timer for given grant runs out, go back to NORMAL
  def tgrant(self):
    print "maneuver_negotiatir.py in the tgrant function, this function is the same as the paper"
    preStatus = self.status
    if  preStatus== self.GRANT or preStatus == self.GRANTGET and hasLeftIntersection(self.grantID):
      self.status = self.NORMAL
      self.grantID = 0
      print "!!! change status from grant to normal"
      if preStatus == self.GRANTGET:
        self.tryManeuver()
    if self.status == self.GRANT or preStatus == self.GRANTGET:
      self.t_grant = threading.Timer(self.TD*2+self.TMan, self.tgrant) #EME Should be set to time at agetn state update - current time + 2TD + TMan
      self.t_grant.start()
      print "!!!threading.Timer"
    print "tgarnt done"

  ## Update the agent state in the register for this car in the storage server
  def update(self):
    print "maneuver_negotiatir.py in the try maneuver function update -. strat"
    # setvalue = str(self.aID) + "," + str(self.agent_state[1]) + "," + str(self.agent_state[2]) + "," + str(self.agent_state[3])
    #IBR: following is not in romi's code, but i think it is needed:
    #print("updating... car {0}".format(self.aID))
    self.agent_state = [self.clock(), self.position(), self.velocity(), self.acceleration()]
    self.agent[1] = self.agent_state
    zookeeper.set(self.handle, "/root/segment/" + str(self.aID), str(self.agent_state)) #Update values stored in zookeeper

    print "\n\n\n\n\n\nself.maneuver_requested",self.maneuver_requested
    print "self.tag[2\n\n\n\n\n\n",self.tag[2]

    if self.maneuver_requested != None:
      MR = self.get_MR(self.agent[0],self.maneuver_requested)
      print "self.agent_state[0] is {}".format(self.agent_state[0])
      print "(RATE*SLOWDOWN) is {}".format((RATE*SLOWDOWN))
      print "MR[0] is {}".format(MR[0])
      print "self.TMan is {}".format(self.TMan)

      if(',' in MR[2]):
        self.agents_to_ask = MR[2].split(',')
      elif MR[2] == '':
        self.agents_to_ask = []
        print("Empty")
      else:
        self.agents_to_ask = [MR[2]]
      print "self.agents_to_ask is {}".format(self.agents_to_ask)
      for car in self.agents_to_ask:
        self.D.add(str(car))
        self.R.add(str(car))
    
    if(self.last() and self.status == self.GET):
      print("last")
      self.tRetry.cancel() #Stop the retry timer
      print("stopped retry timer")   

      if self.DENY not in self.M:
        self.status = self.EXECUTE
      else:
        self.status = self.TRYGET
        print "!!!!change state to TRYGET"
        message = "RELEASE," + str(self.agent[0]) + "," + str(self.agent[1][0]) + "," + str(self.agent[1][1]) + "," \
              + str(self.agent[1][2]) + "," + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1])
        for agents in self.agents_to_ask:
          print(message)
          self.send_udp_message(message,int(agents))
          self.tRetry = Timer(self.TA, self.t_retry, args=(self.maneuver_requested,))
          self.tRetry.start()
    if self.status == self.EXECUTE and hasLeftIntersection(self.aID):
      message = "RELEASE," + str(self.agent[0]) + "," + str(self.agent[1][0]) + "," + str(self.agent[1][1]) + "," \
              + str(self.agent[1][2]) + "," + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1])
      for agents in self.agents_to_ask:
        print(message)
        self.send_udp_message(message,int(agents))
        self.status == self.NORMAL
    print "maneuver_negotiatir.py in the try maneuver function update -. sfinish"

  ## Return true if received tag precedes this agent's permission request tag
  def precedes(self,tagTs):
    print "maneuver_negotiatir.py in the precedes function "
    return (tagTs < self.tag[0])

  ## Return true if the agent ID in the tag belongs to the same agent that is already granted
  def grantedID(self,tagID):
    print "maneuver_negotiatir.py in the grantedId function"
    return (tagID == self.grantID)

  ## Called upon delivery of message to process it's content
  def message_processing(self, message, t):
    print "maneuver_negotiatir.py message_processing, it's a long code, start..."
    #when messages are recived, udp sends data as is without any formatting,
    #so normal string splitting in here works.
    #but if messeges were sent via ros, the message received has a data field, and to get
    #the actual data, invoke message.data to get them. so depending on communication method,
    #things will change to accomodate this:
    curtime = self.clock()
    print"maneuver_negotiatir.py message_processing, curtime-t <= self.TD) .{}".format(curtime - t <= self.TD)
    if (curtime - t <= self.TD): #Only process message if it arrived within the transmission delay boundary
      if (self.communication_details == 1): #if using ros:
        #received string is 'data: "GET,1,1,1,1,1,1,1"' without single quotes,
        # first split extracts the "GET,1,1,1,1,1,1,1" and the second split separates them like usual
        message_split = message.split('"')[1::2][0].split(',')
        print "maneuver_negotiatir.py message_processing, self.communication_details = 1"

      else:
        print "maneuver_negotiatir.py message_processing, self.communication_details != 1"

        message_split = message.split(',')
        mtype = message_split[0]

        if mtype == "GET":
          message_split[3] = message_split[3][1:]
          message_split[5] = message_split[5][:-1]
          m_dict = {"Type":message_split[0], "Sender":message_split[1], "Time":message_split[2],
                "Position":message_split[3:6], "Velocity":message_split[6], "Acc":message_split[7],
                "TagTime":message_split[8], "TagID":message_split[9], "IntendedCourse":message_split[10]}
          print "maneuver_negotiatir.py message_processing,message type is {}, meaasge dict is {}".format(mtype, m_dict)

        if mtype == "DENY":
          m_dict = {"Type":message_split[0], "Sender":message_split[1], "Time":message_split[2],
                "Position":message_split[3:6], "TagTime":message_split[6], "TagID":message_split[7]}
          print "maneuver_negotiatir.py message_processing,message type is {}, meaasge dict is {}".format(mtype, m_dict)

        if mtype == "RELEASE":
          m_dict = {"Type":message_split[0], "Sender":message_split[1], "Time":message_split[2],
                "Position":message_split[3:6], "TagTime":message_split[6], "TagID":message_split[7]}
          print "message type is {}, meaasge dict is {}".format(mtype, m_dict)

        if mtype == "GRANT":
          m_dict = {"Type":message_split[0], "Sender":message_split[1], "Time":message_split[2],
                "Position":message_split[3:6], "TagTime":message_split[6], "TagID":message_split[7]}
          print "maneuver_negotiatir.py message_processing,message type is {}, meaasge dict is {}".format(mtype, m_dict)
      #Decode the messagve

      print ("car " + str(self.aID) + " received " + str(message) + " from  car" + m_dict["Sender"])
      print("status: " + str(self.status))

      if (mtype == "GRANT" or mtype == "DENY") and self.status == self.GET:
        #when a reply is received, membership needs to be queried and
        #vehicles we should get a reply from ie. self.R should be intersection
        #of existing self.R and new membership.
        new_membership = self.get_MR(self.agent[0],self.maneuver_requested)
        print "maneuver_negotiatir.py message_processing,in request processing, exisiting membership = {} ".format(self.R)
        print "maneuver_negotiatir.py message_processing,in request processing, new membership = " , new_membership
        #check if the packet received as membership is valid:
        if(( self.agent_state[0]/(RATE*SLOWDOWN) < new_membership[0] + 2*self.TMan) and new_membership[1] == 1):
          new_R =set(self.R)& set(new_membership[2])
          print "maneuver_negotiatir.py message_processing,in request processing, new R = {}".format(new_R)
        #If this is an answer to our own request for a manoeuvre
        self.M.add(m_dict["Type"]) #Add message to set of received messages
        self.R.discard(m_dict["Sender"]) #Remove this agent from agents we're waiting for
      # The message contains a request
      elif (m_dict["Type"] == "GET"):
        print "maneuver_negotiatir.py message_processing, (m_dict[Type] == GET)"
        mAR = [m_dict["Sender"], m_dict["Time"], m_dict["Position"], m_dict["Velocity"], m_dict["Acc"]]
        if (len(message_split) > 8):
          mAR.append(m_dict["IntendedCourse"])
        #in romi code, time is converted into int
        #if (no_conflict(mAR, int(m_dict["Time"]) + 2*time_delay + TMan) and
        nc = self.no_conflict(mAR, float(m_dict["Time"])) # + 2*self.TD + self.TMan)
        print "maneuver_negotiatir.py message_processing, no conflict"

        if (nc and #If no conflict = the manoeuvre can be executed without risk in the time 2TD + TMan (The expectation of the vehicle is to go)
            (self.status == self.NORMAL or self.status == self.TRYGET or #and (we are either not asking for permission, or asking for permission but waiting for T_retry to expire since all agents in SM not reachable or some sent us DENY
            (self.status == self.GET and self.precedes(m_dict["TagTime"])) or #, or we're asking for permission but this request has a lower timestamp
            ((self.status == self.GRANT or self.status == self.GRANTGET) and 
            self.grantedID == m_dict["TagID"]))): # or we have already given permission to this agent)
          print("maneuver_negotiatir.py message_processing, not conlicted")

          if (self.status == self.NORMAL): #Give permission if you're not making a request yourself and haven't given it to anyone at this moment
            self.status = self.GRANT
            print "maneuver_negotiatir.py message_processing,!!dd342 change status to GRANT"
            self.grantID = m_dict["TagID"]
            print "self.grantID is {}".format(self.grantID)
            #signal simulator that we need to watch the vehicle
            if(self.watch_sender):
              print "watch sender is true"
              self.sim.watch_sender = True
              self.sim.watch_sender_course = self.watch_sender_course
              self.sim.watch_sender_Tman_upperbound = self.watch_sender_Tman_upperbound

          #If you're asking for permission but this request precedes yours,
          # then cancel your own request
          elif (self.status == self.GET or self.status == self.TRYGET): 
            self.tRetry.cancel()
            #Make sure the permissions you've already received are released
            if (self.status == self.GET):
              for agents in self.D:
                s_message = "RELEASE," + str(self.agent[0]) + "," + str(self.agent[1][0]) + "," + str(self.agent[1][1]) + "," \
                          + str(self.agent[1][2]) + "," + str(self.agent[1][3] + "," + str(self.tag[0]) + "," + str(self.tag[1]))
                self.send_udp_message(s_message,int(agents))
            self.status = self.GRANTGET
            print "maneuver_negotiatir.py message_processing,!!dd342 change status to GRANTGET"
            self.grantID = m_dict["TagID"]
          #Send a GRANT to the sender agent

          sender = m_dict["Sender"]
          s_message = "GRANT," + str(self.agent[0]) + "," + str(curtime) + "," + str(self.agent[1][1]) + "," + str(self.agent[1][2]) + "," \
                    + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1])
          #once we grant, we add the car to the list of grants, 
          print(s_message)

          self.risk_estimator.add_car_to_grantlist(int(sender),self.TMan, m_dict["IntendedCourse"])
          self.send_udp_message(s_message,int(sender))
          self.t_grant = threading.Timer(self.TD*2 + self.TMan - self.clock(), self.tgrant) #EME Should be set to time at agetn state update - current time + 2TD + TMan
          self.t_grant.start()
        #DENY otherwise
        else: 
          print "maneuver_negotiatir.py message_processing, woshishui wozainali"
          sender = m_dict["Sender"]
          s_message = "DENY," + str(self.agent[0]) + "," + str(curtime) + "," + str(self.agent[1][1]) + "," + str(self.agent[1][2]) + "," \
                    + str(self.agent[1][3]) + "," + str(self.tag[0]) + "," + str(self.tag[1])
          self.send_udp_message(s_message,int(sender))
      # A release message arrived, check if it's valid and in that case release the current grant
      #EME Have to check that the RELEASE matches the received grant? (self.grantID == m_dict["TagID"] and also comparing the timestamps? 
      #Or is this implicitly handled as Antonio said?)
      elif (m_dict["Type"] == "RELEASE" and (self.status == self.GRANT or self.status == self.GRANTGET) and self.grantedID == m_dict["TagID"]):
        #Stop the grant timer
        print "maneuver_negotiatir.py message_processing, wangquanluanle"
        self.t_grant.cancel()
        self.grantID = 0
        if (self.status == self.GRANT):
          self.status = self.NORMAL
          print "maneuver_negotiatir.py message_processing,!!cc3dd42 change status to NORMAL"
        #remove the granted car from the grant list because we got a release message
        self.risk_estimator.remove_car_from_grantlist(int(m_dict["Sender"]))
        self.risk_estimator.remove_grant_thread.cancel()
        #If you want to send a request, then try to send
        if (self.status == self.GRANTGET):
          self.status = self.TRYGET
          print "maneuver_negotiatir.py message_processing,!!fre3dd42 change status to GRANTGET"
          self.tryManeuver(self.tag[2])
    print "maneuver_negotiatir.py in the message processing function, it's a long code, finish"

  #repurpose this: 
  def setup_ros(self):
    print "maneuver_negotiatir.py start the setip_ros function "
    #subscribe to the measurement channel and update variables
    #lars have split the measurements to one topic per car instead f a single topic
    #rospy.Subscriber(maneuver_negotiator_config.GENERAL_OPTIONS['measurement-topic'],cm.TestMsg,self.update_agent_state_from_ros)
    #subscribeto measurements of self
    self.car_state_subscriber_handle = rospy.Subscriber(maneuver_negotiator_config.ROS_COMMUNICATION_OPTIONS['car-state-topic'][self.aID],\
                                                        cm.CarState, self.update_agent_state_from_ros)
    print "maneuver_negotiatir.py start the setip_ros function  222222"
    #print("setting up maneuver negotiator ros")
    choose_leader_topic = maneuver_negotiator_config.ROS_COMMUNICATION_OPTIONS['maneuver-negotiation-topics']['choose-leader-topic']

    print "maneuver_negotiatir.py start the setip_ros function  3333333"

    self.choose_leader_subscriber_handle = rospy.Subscriber(choose_leader_topic, std_msgs.msg.Int8,self.choose_leader_processor)

    print "maneuver_negotiatir.py start the setip_ros function  44444"
    #if we use the ros to communicate maneuver negotiations between other cars,
    #this car must be publisher to all other cars. as the number of cars can be any number, it is dynamically built.
    #self.other_cars is a dictionary where key is the agent id of the other cars and value is the rospy.pulisher handle
    #so that we can use that to send messages when we want it.
    self.other_cars = {}
    if (self.communication_details == 1):
      print "maneuver_negotiatir.py start the setip_ros function  55555"
      self.sub = rospy.Subscriber(maneuver_negotiator_config.ROS_COMMUNICATION_OPTIONS['maneuver-negotiation-topics'][self.aID][0], \
                                 std_msgs.msg.String, self.ros_message_processor)
      #print("subscribing to " + str(maneuver_negotiator_config.ROS_COMMUNICATION_OPTIONS['maneuver-negotiation-topics'][self.aID][0]))
    print "maneuver_negotiatir.py finish the setip_ros function "

  #repurpose this: 
  def choose_leader_processor(self, data):
    #we receive the message from chooseleader topic.
    #this topic will be the car id that would initiate to do the maneuver negotiation
    #algorithm
    # not used in my code
    print("maneuver_negotiatir.py received messsage from choose leader")
    if data == std_msgs.msg.Int8(self.aID):
      self.tryManeuver()

#repurpose this:
  def udp_msg_processor(self):
    print "maneuver_negotiatir.py start udp_msg_processor funtion"
    sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    #ip to bind
    host_ip = maneuver_negotiator_config.UDP_COMMUNICATION_OPTIONS[self.aID][0]
    port = maneuver_negotiator_config.UDP_COMMUNICATION_OPTIONS[self.aID][1]
    print('udp thread: binding to ' + str((host_ip,port)))
    sock.bind((host_ip, port))
    while 1:
      msg,address = sock.recvfrom(4096)
      print("Received -->>: " )
      t = self.clock()
      self.message_processing(msg, t)

  def ros_message_processor(self,data):
    print "maneuver_negotiatir.py start the ros_message_processor funtion"
    t = self.clock()
    self.message_processing(str(data),t)
    print "maneuver_negotiatir.py finish the ros_message_processor funtion"

  def update_agent_state_from_ros(self,data):
    print "xxx before update is {}".format(self.ros_measurements )
    self.ros_measurements = data
    print "xxx after update is {}".format(self.ros_measurements )
    print "maneuver_negotiatir.py finish the update agent state from ros funtion"

  def send_udp_message(self,message,agent_id):
    #port number is derived from car id.
    #car id ranges from 1 to 254
    #port number ranges from port_prefix+carid to uppper limit 
    #since all cars exist in same network, but ip addresses are 
    #different, 
    #car_id = int(agent_port) - communication_config.NETWORK_OPTIONS['port-start']
    #this is to simulate breaking of connection after certain time, this is to be done by 
    #network simulater in later stages
    print "maneuver_negotiatir.py start the update_agent_message"
    tim = self.clock()
    if (GEN_CONFIG["break_communication"] and self.aID in GEN_CONFIG["communication_breaking_cars"] and tim > GEN_CONFIG["communication_break_time"]):
      print "return from send_udp_message"
      return 
    if self.communication_details == 0:
      print "self.communication_details == 0"
      car_id = agent_id
      target_car_ip = maneuver_negotiator_config.UDP_COMMUNICATION_OPTIONS[car_id][0]
      sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
      agent_port = maneuver_negotiator_config.UDP_COMMUNICATION_OPTIONS[car_id][1]
      print("sending {0} to car {1} from car {2}".format(message,agent_id,self.aID))
      #print("agent id = " + str(agent_id))
      #print(str((target_car_ip,agent_port)))
      sock.sendto(message, (target_car_ip, agent_port))
      sock.close()
    else:
      print "self.communication_details == 0 xxxxxxx"
      #we use ros:
      #check if we have the target agent_id's publish handle
      if agent_id in self.other_cars:
        publisher = self.other_cars[agent_id]
      else:
        self.other_cars[agent_id] = rospy.Publisher(maneuver_negotiator_config.ROS_COMMUNICATION_OPTIONS['maneuver-negotiation-topics'][agent_id][0],\
                                                    std_msgs.msg.String,queue_size=10)
      print("sending {0} to car {1} by car {2}".format(message,agent_id,self.aID))
      publisher = self.other_cars[agent_id]
      publisher.publish(std_msgs.msg.String(message))
    print "maneuver_negotiatir.py finish the update_agent_message"
      # if not, we make a new publisher and use that
      # if we have, we use that handle to publish message
      
  def initialize(self):

    print "maneuver_negotiatir.py in the maneuver negotiatir.py the initialize function -- start"

    #self.handle = zookeeper.init(communication_config.NETWORK_OPTIONS['zookeeper-server'])
    devnull = open(os.devnull,"w")
    zookeeper.set_log_stream(devnull)
    self.handle = zookeeper.init(maneuver_negotiator_config.GENERAL_OPTIONS['zookeeper-server'])
    self.t_update = Timer(self.TA, self.update)
    self.t_update.start()

    print "maneuver_negotiatir.py call setup_ros function"

    self.setup_ros()

    print "maneuver_negotiatir.py start thread that listens on network for udp packets from other cars"
    print "maneuver_negotiatir.py start a thread to udp massage"

    net_thread = threading.Thread(target= self.udp_msg_processor)
    net_thread.start()

    print "maneuver_negotiatir.py in the maneuver_negotiatir.py the initialize function -- finish"
    #rospy spinning to be done by the main method which creates this class.
    #spinning here will make the initialize() in a loop where
    #it cannot return to the main method. 
    #rospy.spin()
