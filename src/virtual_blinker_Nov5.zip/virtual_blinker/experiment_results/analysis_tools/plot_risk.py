import matplotlib.pyplot as plt
import csv
#import matplotlib.lines as mlines

time = []
risk = []

with open("../Test_1/1541082879__mn_risk.csv") as risk_data:
    reader = csv.reader(risk_data, delimiter=',')
    nmb_vehicles = len(next(reader)) -1
    #print(nmb_vehicles)
    risk_data.seek(0)
    for i in range(0,nmb_vehicles):
        risk.append([])
    for row in reader:
        time.append(row[0])
        for j in range(0, nmb_vehicles):
            risk[j].append(row[j+1])
        #print(", ".join(row))

for i in range(0, nmb_vehicles):
    plt.plot(time, risk[i], label="vehicle " + str(i), linewidth=2,)
plt.xlabel("Time (s)")
plt.ylabel("Risk")
plt.axis([0, int(round(float(time[-1]))), -0.1, 1.1])
plt.legend()
plt.show()
